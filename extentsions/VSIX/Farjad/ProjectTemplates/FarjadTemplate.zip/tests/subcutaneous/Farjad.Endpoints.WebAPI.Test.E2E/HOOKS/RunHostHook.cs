﻿using $safeprojectname$.Tools;
using $safeprojectname$.Tools.NetCoreHosting;

namespace $safeprojectname$.Hooks
{
    [Binding]
    public sealed class RunHostHook
    {
        private static readonly DotNetCoreHost Host =
            new DotNetCoreHost(new DotNetCoreHostOptions
            {
                Port = HostConstants.Port,
                CsProjectPath = HostConstants.CsProjectPath
            });

        [BeforeFeature]
        public static void StartHost()
        {
            Host.Start();
        }

        [AfterFeature]
        public static void ShutdownHost()
        {
            Host.Stop();
        }
    }
}
