﻿namespace $safeprojectname$.Tools.Core
{
    public interface IHost
    {
        string BaseUrl { get; }
    }
}
