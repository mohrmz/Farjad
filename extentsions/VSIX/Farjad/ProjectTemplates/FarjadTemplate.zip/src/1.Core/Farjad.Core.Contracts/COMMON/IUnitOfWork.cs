﻿using Farjad.Core.Contracts.Data.Commands;

namespace $ext_projectname$.Core.Contracts.Common
{
    public interface I$ext_projectname$UnitOfWork : IUnitOfWork
    {
    }
}