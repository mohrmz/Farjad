﻿namespace $safeprojectname$.Tools.NetCoreHosting
{
    public class DotNetCoreHostOptions
    {
        public string CsProjectPath { get; set; }
        public int Port { get; set; }
    }
}
