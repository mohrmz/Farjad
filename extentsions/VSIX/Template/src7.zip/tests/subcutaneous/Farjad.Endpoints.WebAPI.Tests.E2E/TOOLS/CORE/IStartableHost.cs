﻿namespace $safeprojectname$.Tools.Core
{
    public interface IStartableHost : IHost
    {
        void Start();
        void Stop();
    }
}
